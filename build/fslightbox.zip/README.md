# Fullscreen Lightbox Basic

## Version - 1.5.2

## Description
Fullscreen Lightbox is vanilla JS plugin for displaying images and videos in clean overlaying box.

Website: https://fslightbox.com

Open source project.
Technologies:
- JavaScript
- SCSS
### No jQuery and other dependencies.

## Installation
Clone repository cd to directory and run:
````
 npm install
 ````
 
To run gulp server with tasks:
````
 gulp
 ````
